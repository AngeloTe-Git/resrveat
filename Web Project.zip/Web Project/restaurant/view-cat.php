

<div class="col-sm-7">
                            <div class="card main" style="height:450px">
                                <div class="card-body">
                                    <div class="table-wrapper-scroll-y my-custom-scrollbar2" style="height:400px">
                                            <table id="table" class="table table-bordered table-striped"> 
                                                <thead class="text-light bg-dark">
                                                    <tr>      
                                                        <th>Category</th>
                                                        <th>Image</th>     
                                                        <th>Name</th>       
                                                        <th>Price</th>
                                                    </tr>  
                                                </thead>   
                                                <tbody>
                                                    <?php
                                                        require 'connection.php';
                                                        require 'menu.php';
                                                    ?> 
                                                </tbody>
                                            </table> 
                                    </div> 
                                </div>
                            </div>
                        </div> 