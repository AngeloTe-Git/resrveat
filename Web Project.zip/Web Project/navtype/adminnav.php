<nav class="navbar navbar-expand-lg navbar-light sticky-top bg-light" style = "background-color: #FF914D">
  <div class="container col-md-10">
    <a class="navbar-brand" href="index.php"><img src= "images/reserveat-icon.png" style = "height: 150px"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="landing.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Signout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>