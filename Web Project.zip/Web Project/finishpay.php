<?php
$log_err="";
session_start();
require 'connection.php';
require_once 'includes/header.php';
require_once 'includes/nav.php';
?>
    <div class="container">
        <div class="jumbotron jumbotron-fluid py-2 mt-3" style="height:700px">
            <div class="form-container">
                <h1>Thank you for using ReservEat</h1>
            </div>
            
        </div>
    </div>


<?php
require_once 'includes/footer.php';
?>